/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body for optical sensor
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//begin///////////////////////////////////////////////////////////////////////////////////////////
//TODO: Debug only — remove before production
#include <stdio.h>
#include <string.h>
//end/////////////////////////////////////////////////////////////////////////////////////////////
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// DMA_BUF_SIZE: Number of pulse timestamps stored in RAM before the buffer wraps.
// A larger buffer provides a "safety cushion," giving the CPU more time to
// process data before the DMA hardware overwrites it.
#define DMA_BUF_SIZE	4

// SLOTS_ON_DISK: The physical number of holes/slots in your optical encoder disk.
// This is the primary constant for converting pulse frequency to shaft rotation.
#define SLOTS_ON_DISK  	18

// MINIMUM_RPM: The speed floor. If the time between pulses exceeds the time
// equivalent to this RPM, the 'timeout logic' will force the RPM to 0.
// Prevents the system from displaying a "stale" RPM when the motor stops.
// The higher the MINIMUM_RPM, the shoerter the timeout time
#define MINIMUM_RPM    	5

// CALC_WINDOW_SIZE: The number of pulses averaged for a single RPM calculation.
// Since we process data at the Half-Transfer and Transfer-Complete interrupts,
// we calculate RPM every (DMA_BUF_SIZE / 2) pulses.
#define CALC_WINDOW_SIZE (DMA_BUF_SIZE / 2)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
DMA_HandleTypeDef hdma_tim2_ch1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart1_tx;

/* USER CODE BEGIN PV */
uint32_t last_lcd_update = 0;
uint32_t capture_buffer[DMA_BUF_SIZE];

// Indices for the end of the first half and total buffer
// These define our "capture windows" for the DMA interrupts
uint8_t CALC_WINDOW_MAX_IDX = CALC_WINDOW_SIZE - 1;
uint8_t DMA_BUF_MAX_IDX = DMA_BUF_SIZE - 1;

// Conversion Constant Calculation:
// We measure ticks between pulses. To get RPM:
// RPM = (60,000,000 us/min) / (Time for 1 revolution in us)
// Time for 1 rev = (Avg time between pulses) * SLOTS_ON_DISK
float conversion_factor = (60000000.0f * CALC_WINDOW_SIZE) / SLOTS_ON_DISK;

uint32_t last_pulse_timestamp = 0; 	// Stores the final timestamp of the previous DMA batch
volatile uint32_t period_ticks = 0; // Raw timer ticks over the current window
volatile uint8_t new_rpm_data = 0;  // Semaphore flag to signal main loop processing
float current_rpm = 0; 				// Resultant filtered RPM

float current_pwm = 0;

// Sliding window for spike rejection
float median_buffer[3] = {0, 0, 0};
uint8_t median_idx = 0;

// Smoothing factor (Lower = smoother but slower response. 30% weight to new data, 70% to history)
float alpha = 0.3f;

// Calculate max allowable time between pulses before assuming motor has stopped
float timeout_ms = 60000.0f / (MINIMUM_RPM * SLOTS_ON_DISK);
uint32_t last_tick = 0; // For timeout logic

char esp32_buffer[10]; 				// buffer for rpm string to be sent to ESP32
uint32_t last_ESP32_transmit = 0;	// used to transmit to ESP32 after every 100ms

//begin///////////////////////////////////////////////////////////////////////////////////////////
//TODO: Debug only — remove before production
static uint32_t last_print = 0;
//end/////////////////////////////////////////////////////////////////////////////////////////////

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
float get_median_of_3(float a, float b, float c) {
    if ((a <= b && b <= c) || (c <= b && b <= a)) return b;
    if ((b <= a && a <= c) || (c <= a && a <= b)) return a;
    return c;
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#define LCD_ADDR (0x27 << 1)   // your backpack address

static uint8_t lcd_backlight = 0x08;  // backlight ON

static void lcd_write(uint8_t data)
{
    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &data, 1, HAL_MAX_DELAY);
}

static void lcd_pulse(uint8_t data)
{
    lcd_write(data | 0x04);    // EN=1
    HAL_Delay(1);
    lcd_write(data & ~0x04);   // EN=0
    HAL_Delay(1);
}

static void lcd_write4(uint8_t nibble, uint8_t rs)
{
    uint8_t data = 0;

    // P0=RS, P1=RW, P2=EN, P3=Backlight, P4..P7=D4..D7
    if (rs) data |= 0x01;
    data |= lcd_backlight;
    data |= (nibble & 0xF0);

    lcd_pulse(data);
}

static void lcd_cmd(uint8_t cmd)
{
    lcd_write4(cmd & 0xF0, 0);
    lcd_write4((cmd << 4) & 0xF0, 0);
    HAL_Delay(2);
}

static void lcd_data(uint8_t data)
{
    lcd_write4(data & 0xF0, 1);
    lcd_write4((data << 4) & 0xF0, 1);
    HAL_Delay(1);
}

static void lcd_init(void)
{
    HAL_Delay(50);

    lcd_write4(0x30, 0); HAL_Delay(5);
    lcd_write4(0x30, 0); HAL_Delay(1);
    lcd_write4(0x30, 0); HAL_Delay(1);
    lcd_write4(0x20, 0); HAL_Delay(1);

    lcd_cmd(0x28); // 4-bit, 2-line (works fine for 20x4)
    lcd_cmd(0x0C); // display ON
    lcd_cmd(0x01); // clear
    HAL_Delay(5);
    lcd_cmd(0x06); // entry mode
}

static void lcd_set_cursor(uint8_t row, uint8_t col)
{
    static const uint8_t row_offsets[] = {0x00, 0x40, 0x14, 0x54};
    lcd_cmd(0x80 | (row_offsets[row] + col));
}

static void lcd_print(const char *s)
{
    while (*s) lcd_data((uint8_t)*s++);
}
//begin///////////////////////////////////////////////////////////////////////////////////////////
//TODO: Debug only — remove before production
int __io_putchar(int ch) {
    HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}
//end///////////////////////////////////////////////////////////////////////////////////////////

//begin///////////////////////////////////////////////////////////////////////////////////////////
//TODO: Debug only — remove before production
//CPU cylce tracking
void DWT_Init(void) {
    // 1. Enable the trace peripheral (required for DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

    // 3. Reset the cycle counter
    DWT->CYCCNT = 0;

    // 4. Start the cycle counter
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}
uint32_t start, end, duration;
volatile float acc_isr_half = 0;    // RPM Sensor Interrupt
volatile float acc_isr_full = 0;  // Motor PWM/Control Interrupt
float acc_main_logic = 0;          // Your if(new_rpm_data) block
float load_half_pct = 0;
float load_full_pct = 0;
float load_main_pct = 0;
float last_report_tick = 0;
float acc_idle_cycles = 0;
float load_idle_pct = 0;
//end///////////////////////////////////////////////////////////////////////////////////////////

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  lcd_init();

  lcd_set_cursor(0, 0);
  lcd_print("Senior Project Demo ");

  lcd_set_cursor(1, 0);
  lcd_print("Optical RPM Sensor  ");
  // This tells the DMA: "Every time TIM2 captures a value, put it in capture_buffer."
  HAL_TIM_IC_Start_DMA(&htim2, TIM_CHANNEL_1, capture_buffer, DMA_BUF_SIZE);

  //begin///////////////////////////////////////////////////////////////////////////////////////////
  //TODO: Debug only — remove before production
  DWT_Init();
  
  uint8_t print = 1;
  uint8_t last_button = 1;
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
  
  printf("----------------------------------------------------------------------\r\n");
  printf("----------------------------------------------------------------------\r\n");
  printf("----------------------------------------------------------------------\r\n");
  //end/////////////////////////////////////////////////////////////////////////////////////////////

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


	  // Process new RPM measurement if a DMA interrupt has occurred
	  if (new_rpm_data) {
      //begin///////////////////////////////////////////////////////////////////////////////////////////
      //TODO: Debug only — remove before production
		  start = DWT->CYCCNT;
      //end///////////////////////////////////////////////////////////////////////////////////////////

		  new_rpm_data = 0;

		  // Step 1: Calculate raw RPM from timer ticks
		  float rpm_raw = conversion_factor / (float)period_ticks;

		  // Step 2: Median Filter - Rejects single-point noise/glitches
		  median_buffer[median_idx] = rpm_raw;
		  median_idx++;
		  if (median_idx >= 3) {
			  median_idx = 0;
		  }
		  float rpm_filtered = get_median_of_3(median_buffer[0], median_buffer[1], median_buffer[2]);


		  // Step 3: Complementary Alpha Filter - Smooths out quantization jitter
		  current_rpm = (alpha * rpm_filtered) + ((1.0f - alpha) * current_rpm);

		  // Update timeout timestamp
		  last_tick = HAL_GetTick();

      //begin///////////////////////////////////////////////////////////////////////////////////////////
      //TODO: Debug only — remove before production
		  acc_main_logic += (DWT->CYCCNT - start);
      //end/////////////////////////////////////////////////////////////////////////////////////////////
	  }


	  // transmit current RPM and PWM to ESP32 for graphing
	  if (HAL_GetTick() - last_ESP32_transmit >= 100) {
		  // Only send if the previous DMA transfer is finished
		  if (huart1.gState == HAL_UART_STATE_READY) {

			  // Example: current_rpm = 1500, current_pwm = 75 -> "1500,75\n"
			  int len = sprintf(esp32_buffer, "%d,%d\n", (int)current_rpm, (int)current_pwm);

			  // Transmit to ESP32 via UART1
			  HAL_UART_Transmit_DMA(&huart1, (uint8_t*)esp32_buffer, len);

			  last_ESP32_transmit = HAL_GetTick();
		  }
	  }



    //begin///////////////////////////////////////////////////////////////////////////////////////////
    //TODO: Debug only — remove before production
//	  // --- The Auditor: Calculate results every 1 second ---
//	  if (print && (HAL_GetTick() - last_report_tick >= 1000)) {
//      // Calculate percentages (Assuming 180MHz)
//		  load_half_pct = ((float)acc_isr_half * 100) / 180000000;
//		  load_full_pct = ((float)acc_isr_full * 100) / 180000000;
//		  load_main_pct = ((float)acc_main_logic * 100) / 180000000;
//
//		  printf("--- CPU LOAD REPORT ---\r\n");
//		  printf("Half ISR:  %.4f%%\r\n", load_half_pct);
//		  printf("Full ISR:  %.4f%%\r\n", load_full_pct);
//		  printf("Main Math: %.4f%%\r\n", load_main_pct);
//		  printf("Total:     %.4f%%\r\n\n", load_half_pct + load_full_pct + load_main_pct);
//
//		  // Reset all accumulators
//		  acc_isr_half = 0;
//		  acc_isr_full = 0;
//		  acc_main_logic = 0;
//		  acc_idle_cycles = 0;
//		  last_report_tick = HAL_GetTick();
//	  }
    //end/////////////////////////////////////////////////////////////////////////////////////////////



	  // timeout logic to detect when RPM = 0 (If no pulses seen for too long, set RPM to zero)
	  if (HAL_GetTick() - last_tick > (uint32_t)timeout_ms) {
		  current_rpm = 0;
		  median_buffer[0] = median_buffer[1] = median_buffer[2] = 0;
	  }


    //begin///////////////////////////////////////////////////////////////////////////////////////////
    //TODO: Debug only — remove before production
	  // start and stop printing to serial on button1 press
	  uint8_t current_button = HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin);
	  if (last_button == GPIO_PIN_SET && current_button == GPIO_PIN_RESET)
	  {
      print = !print;
      HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
	  }
	  last_button = current_button;
    
	  // Print RPM to Serial every 100ms
	  if (print && (HAL_GetTick() - last_print > 100))
	  {
      printf("%.0f\r\n", current_rpm);
		  last_print = HAL_GetTick();
	  }
    //end/////////////////////////////////////////////////////////////////////////////////////////////
	  if (HAL_GetTick() - last_lcd_update >= 200)   // update 5x/sec
	  {
	      last_lcd_update = HAL_GetTick();

	      char line[21];

	      lcd_set_cursor(2, 0);
	      snprintf(line, sizeof(line), "RPM: %4d           ", (int)(current_rpm + 0.5f));
	      lcd_print(line);

	      lcd_set_cursor(3, 0);
	      snprintf(line, sizeof(line), "PWM: %3d%%          ", (int)(current_pwm + 0.5f));
	      lcd_print(line);
	  }

  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 90-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 10;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
  /* DMA2_Stream7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

// Triggered when DMA fills the FIRST half of the buffer (Indices 0 to CALC_WINDOW_MAX_IDX)
// CALC_WINDOW_MAX_IDX = (DMA_BUF_SIZE / 2) - 1
void HAL_TIM_IC_CaptureHalfCpltCallback(TIM_HandleTypeDef *htim)
{
  //begin///////////////////////////////////////////////////////////////////////////////////////////
  //TODO: Debug only — remove before production
	start = DWT->CYCCNT;
  //end/////////////////////////////////////////////////////////////////////////////////////////////

  // Calculate time elapsed from the end of the previous DMA batch to the end of this half.
  // This ensures we don't lose the "gap" between interrupts.
  period_ticks = capture_buffer[CALC_WINDOW_MAX_IDX] - last_pulse_timestamp;

  // Save last timestamp of the first half to be used for calculation of second half
  last_pulse_timestamp = capture_buffer[CALC_WINDOW_MAX_IDX];

  new_rpm_data = 1;

  //begin///////////////////////////////////////////////////////////////////////////////////////////
  //TODO: Debug only — remove before production
  acc_isr_half += (DWT->CYCCNT - start);
  //end////////////////////////////////////////////////////////////////////////////////////////////
}


// Triggered when DMA fills the SECOND half of the buffer (Indices CALC_WINDOW_SIZE to DMA_BUF_MAX_IDX)
// CALC_WINDOW_SIZE = DMA_BUF_SIZE / 2
// DMA_BUF_MAX_IDX = DMA_BUF_SIZE - 1
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
  //begin///////////////////////////////////////////////////////////////////////////////////////////
  //TODO: Debug only — remove before production
	start = DWT->CYCCNT;
  //end////////////////////////////////////////////////////////////////////////////////////////////

	// Calculate time elapsed from the end of the first half to the end of the buffer
  period_ticks = capture_buffer[DMA_BUF_MAX_IDX] - last_pulse_timestamp;

  // Save last timestamp of second half to be used for calculation of first half of next buffer
  last_pulse_timestamp = capture_buffer[DMA_BUF_MAX_IDX];
  new_rpm_data = 1;

  //begin///////////////////////////////////////////////////////////////////////////////////////////
  //TODO: Debug only — remove before production
  acc_isr_full += (DWT->CYCCNT - start);
  //end////////////////////////////////////////////////////////////////////////////////////////////
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
